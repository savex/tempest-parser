__author__ = 'savex'

from src.reporter.html_reporter import HtmlReport
from src.reporter.csv_reporter import CSVReporter
from src.manager.test_manager import TestsManager
from src.parser.tempest_log_parser import TempestLogParser
from src.manager.importers import XMLImporter
from src.reporter.google_reporter import GoogleReporter

import os
import sys
import argparse


class MyParser(argparse.ArgumentParser):
    def error(self, message):
        sys.stderr.write('Error: {0}\n\n'.format(message))
        self.print_help()
        sys.exit(2)


def help_message():
    print"Please, supply tempest cli log file or folder full of it as an only parameter"

    return


# main
def tempest_cli_parser_main():
    parser = MyParser(prog="Tempest CLI Parser")

    parser.add_argument(
        "filepath",
        help="tempest cli log file or folder full of it"
    )

    parser.add_argument(
        "-c",
        "--csv-file",
        help="Force output to CSV"
        #default="parsed.csv"
    )

    parser.add_argument(
        "-k",
        "--config-file",
        help="Dafault. Configuration file for accessing Google Spreadsheets"
        #default="google.conf"
    )

    args = parser.parse_args()

    # At this point we must load tests to combine executions with
    # for now it will be all tests
    print("Pre-loading tests...")
    tests_manager = TestsManager()
    log_parser = TempestLogParser(tests_manager)

    # # Parse objects from raw file
    # # and Collect / sort objects into executions and parse them
    if os.path.isfile(args.filepath):
        # this is a file
        log_parser.object_parser(
            log_parser.cli_parser(args.filepath)
        )
    else:
        # this is a folder, get files one by one
        _folder_content = os.listdir(args.filepath)

        for _file in _folder_content:
            # parse log files
            if _file.endswith(".log"):
                log_parser.object_parser(
                    log_parser.cli_parser(
                        os.path.join(
                            args.filepath,
                            _file
                        )
                    )
                )
            if _file.endswith(".xml"):
                # this is an xml file, parse it using specific importer
                xml_importer = XMLImporter(
                    tests_manager,
                    os.path.join(
                        args.filepath,
                        _file
                    )
                )
                xml_importer.parse_xml()

    # print("Generating HTML report...")
    # report = HtmlReport(tests_manager)
    # html_page = report.render_report(tests_manager.get_tests_list(), 'tmp.html')

    if args.config_file is not None:
        print("Reporting to Google Spreadsheet")
        # auth
        g_reporter = GoogleReporter(args.config_file, tests_manager)
        # report
        g_reporter.update_worksheet()

        pass

    if args.csv_file is not None:
        print("Generating CSV report...")
        csv_reporter = CSVReporter(tests_manager)
        csv_reporter.generate_to_file(args.csv_file)


if __name__ == '__main__':
    tempest_cli_parser_main()
    # sys.exit(0)
