__author__ = 'savex'

from src.utils.file import *
from datetime import date

class CSVReporter():
    # csv file will list all of the test runs
    # ##, name, testrun1, , testrun2, , ...
    # ,class_announce,,,,,
    # ##, test_name,result1,result2,...

    def __init__(self, test_manager):
        self.test_manager = test_manager
        self._tests = self.test_manager.get_tests_list()
        self._total_executions = sorted(self._tests["executions"].keys())
        return

    def generate_to_file(self, filename):
        # clear file content if any
        try:
            remove_file(filename)
        except OSError as e:
            pass

        ## header
        csv_header = ", class/test name,"
        _result_columns = 0
        ## execution names for header
        for _execution in self._total_executions:
            #execution name
            #csv_header += _execution + ','
            _date_prepared = self._tests['executions'][_execution]
            _date_prepared = _date_prepared.replace('/','\n')
            _date_prepared = _date_prepared.replace(' ','\n')
            csv_header += '"' + _date_prepared + '",'
            _result_columns += 1

        append_line_to_file(filename, csv_header)
        _tests_counter = 0

        ## lines
        for class_name in sorted(self._tests['tests'].keys()):
            # printing out class line
            _class_line = 'Class' + \
                          ',' + \
                          class_name + \
                          ','
            for i in range(0, _result_columns):
                _class_line += ',' + ','
            #write class line
            append_line_to_file(filename, _class_line)

            # iterate tests
            for _test in self._tests['tests'][class_name]:
                _tests_counter += 1
                _test_line = str(_tests_counter) + ',' + _test['test_name'] + _test['test_options'] + ','
                #iterate results
                _results = ""

                #Add a Required/Added mark to results
                if _test['results'].has_key('required'):
                    _results += _test['results']['required']['result'] + ','
                else:
                    _results += 'A' + ','

                #Iterate other results
                for _execution in self._total_executions:
                    if _execution != 'required':
                        if _test['results'].has_key(_execution):
                            # new template has no 'time' mark, just comment it out
                            _results += _test['results'][_execution]['result'] + ','
                            #_results += _test['results'][_execution]['time'] + ','
                        else:
                            #_results += ',' + ','
                            _results += ','
                append_line_to_file(filename, _test_line + _results)