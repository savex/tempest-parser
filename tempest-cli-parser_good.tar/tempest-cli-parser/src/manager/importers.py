__author__ = 'savex'

import xml.etree.ElementTree as ET

from src.utils.file import *

class XMLImporter():
    def __init__(self, test_manager, filename):
        self.tree = ET.parse(filename)
        self.root = self.tree.getroot()
        self.tm = test_manager

    def _parse_duration(self, duration):
        _time_in_sec = float(duration) / 1000.0
        return str(_time_in_sec) + 's'

    def _parse_status(self, status):
        return {
            'passed': 'OK',
            'failed': 'FAIL',
            'ignored': 'SKIP',
            'error': 'FAIL'
        }[status]

    def _add_execution(self, name, duration):
        self.tm.add_execution(
            dict(
                execution_name=name,
                summary=dict(
                    time=self._parse_duration(duration)
                )
            )
        )

        time = 0

    def parse_xml(self):
        _execution_name = self.root.attrib['name'].lower()

        # iterate through classes
        for _class_node in self.root.findall('suite'):
            # iterate through tests
            _class_name = _class_node.attrib['name']
            #remove any '%' symbols and following number

            _symbol_index = _class_name.find('%')
            if _symbol_index > 0:
                _class_name = _class_name[:_symbol_index] + _class_name[_symbol_index+2:]

            for _test_node in _class_node.findall('test'):
                # get all attributes from xml
                _test_name = _test_node.attrib['name']
                _duration = "0s"
                try:
                    _duration = self._parse_duration(_test_node.attrib['duration'])
                except KeyError:
                    pass
                _status = self._parse_status(_test_node.attrib['status'])

                # add this result to list
                self.tm.add_result_for_test(
                    _execution_name,
                    _class_name,
                    _test_name,
                    _status,
                    _duration,
                    class_name_short=True
                )
                for _output in _test_node.findall('output'):
                    _type = _output.attrib['type']
                    _trace = ""
                    _message = ""

                    if _type == 'stdout':
                        # no trace present
                        _message = _output.text
                    elif _type == 'stderr':
                        _trace = _output.text

                    self.tm.add_fail_data_for_test(
                        _execution_name,
                        _class_name,
                        _test_name,
                        _trace,
                        _message,
                        class_name_short=True
                    )

        self._add_execution(_execution_name, self.root.attrib['duration'])

        return _execution_name